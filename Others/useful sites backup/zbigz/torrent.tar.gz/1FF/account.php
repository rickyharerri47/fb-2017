<?php

$this->acc = array(
# Example: 'accounts'	=> array('user:pass','cookie'),
# Example with letitbit.net: 'accounts'    => array('user:pass','cookie','prekey=xxxx'),


	'alldebrid.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'datafilehost.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array('123123:123123',),
							),
							
	'Bigfile.to'		=> array(
								'max_size'	=> 1024,
								'accounts'	=> array('123132:123123',),
							),
							

	'conexaomega.com.br'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'contasturbo.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'debriditalia.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'debridmax.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),
							
	'premiumize.me'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array('','675948871:uaeb8qhhppxsfhps',),
							),

							

	'downmasters.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),
							
	'Junocloud.me'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array('123123:123123',),
							),
							
							
	'Openload.co'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array('132132:123132',),
							),	
							

	'fast-debrid.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'ffdownloader.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'linksnappy.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'megarapido.net'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'multi-debrid.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'premiumize.me'		=> array(
								'max_size'	=> 512,
								'accounts'	=> array(),
							),

	'real-debrid.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'rehost.to'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'rpnet.biz'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'simply-debrid.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'superdown.com.br'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'superlinksbr.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'zevera.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'1fichier.com'		=> array(
								'max_size'	=> 1024,
								'accounts'	=> array('123132:123123',),
							),

	'2shared.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'bayfiles.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'bitshare.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'cloudnator.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'crocko.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'datafile.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'ddlstorage.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'depfile.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'depositfiles.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'enterupload.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'extabit.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'fileape.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'filecloud.io'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'filefactory.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array('stringsbeast@gmail.com:4z3rtyk123',),
							),

	'fileflyer.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'filejungle.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'fileopic.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'filepost.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'filereactor.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'fileserve.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'filesmonster.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'filesonic'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'filevelocity.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'freakshare.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'free.fr'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'gigasize.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'hipfile.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'hotfile.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'jumbofiles.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'letitbit.net'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'lumfile.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'mediafire.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array('123123:123132',),
							),

	'megashares.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'mega.nz'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array('123123:123123',),
							),

	'megavideo.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'netload.in'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'novafile.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'openload.co'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array("123123:123123",),
							),

	'putlocker.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'rapidgator.net'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array('123123:123123',),
							),

	'rapidshare.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'rarefile.net'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'ryushare.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'sendspace.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'shareflare.net'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'share-online.biz'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'sourceforge.net'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'turbobit.net'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array('123123:123123',),
							),

	'unibytes.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'uploaded.to'		=> array(
								'max_size'	=> 256,
								'accounts'	=> array('login=%26id%3D13631126%26pw%3D703ca35fde7af9ee11f05717200c7a250c226f25%26cks%3D2bc001bcbf4a','login=%26id%3D14748506%26pw%3Defa93fd4a43ba80c289fbbe968a4974e6b79e798%26cks%3D696067b627e8','3370688:d7c9ymgi',),
							),

	'uploaded.net'		=> array(
								'max_size'	=> 256,
								'accounts'	=> array('123132:123123',),
							),

	'uploadhero.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'uploading.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'uploadjet.net'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'uploadstation.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'uptobox.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array('123132:123123',),
							),

	'vip-file.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

	'wupload'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

);
$this->max_size_other_host = 20480;

?>