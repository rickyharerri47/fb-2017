<?php

$this->acc = array(
# Example: 'accounts'	=> array('user:pass','cookie'),
# Example with letitbit.net: 'accounts'    => array('user:pass','cookie','prekey=xxxx'),


	'simply-debrid.com'		=> array(
								'max_size'	=> 5240,
								'accounts'	=> array(),
							),

	'redtube.com'		=> array(
								'max_size'	=> 5240,
								'accounts'	=> array('12345:145874',),
							),

	'1fichier.com'		=> array(
								'max_size'	=> 1024,
								'accounts'	=> array('sevre93@hotmail.com:sevre','Titi360_16@hotmail.com:100288','taherantar@hotmail.com:GetBackers','mccartyser@roadrunner.com:dianabob','Kinobi.is.back@gmail.com:kinobi','squall69@orange.fr:sq69ol83',),
							),

	'xhamster.com'		=> array(
								'max_size'	=> 5240,
								'accounts'	=> array('byMrBLAKEN/:154651rtret5r51ez1561ztzzrt1zt163',),
							),

	'uptobox.com'		=> array(
								'max_size'	=> 25600,
								'accounts'	=> array('dada442301:noemie2006',),
							),

	'filefactory.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array('byMrBLAKEN/:154651rtret5r51ez1561ztzzrt1zt163',),
							),

	'xnxx.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array('byMrBLAKEN/:154651rtret5r51ez1561ztzzrt1zt163',),
							),

	'yuvutu.com'		=> array(
								'max_size'	=> 15360,
								'accounts'	=> array('byMrBLAKEN/:154651rtret5r51ez1561ztzzrt1zt163',),
							),

	'depositfiles.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array('byMrBLAKEN/:user',),
							),

	'datafile.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array('dean_eisel@hotmail.com:slayer65',),
							),

	'youjizz.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array('byMrBLAKEN/:154651rtret5r51ez1561ztzzrt1zt163',),
							),

	'secureupload.eu'		=> array(
								'max_size'	=> 4096,
								'accounts'	=> array(),
							),

	'netload.in'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array('1358883:ygt456yhj','1363557:rgh567ujk',),
							),

	'easy-share.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'mediafire.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array('byMrBLAKEN/:newsservtest',),
							),

	'uploaded.to'		=> array(
								'max_size'	=> 8048,
								'accounts'	=> array('login=%26id%3D8234814%26pw%3D64456dcbe4f4ffd06519f4a2635f7f535ebb43f6%26cks%3De86424fbb72e','login=%26id%3D7123804%26pw%3Ded7d27754906f4a2fc951a667504ce3f532142a5%26cks%3D4d2db911bd65','login=%26id%3D11118354%26pw%3D78510f249d8acadab7d0fd6e697b0644ab16f833%26cks%3D59c5740a210e','login=%26id%3D8234814%26pw%3D64456dcbe4f4ffd06519f4a2635f7f535ebb43f6%26cks%3De86424fbb72e','login=%26id%3D8234814%26pw%3D64456dcbe4f4ffd06519f4a2635f7f535ebb43f6%26cks%3De86424fbb72e','login=%26id%3D3127078%26pw%3D4e3550d20e17fefb196fcd580238bf39f6d40615%26cks%3D36f5b6236ddb','login=%26id%3D6073663%26pw%3Dd5ef242ed02a4e60eacdc60c93c5fd113aaaeac2%26cks%3D30e5861a3f06','login=%26id%3D7642582%26pw%3D2f58b68ab502319b74b5653840a241ebfbe1ea40%26cks%3Dc321d169e3e8','login=%26id%3D4489564%26pw%3Da5c21b0d64cd4b751b48f6733feef6f31f9df98b%26cks%3D2d001fb0bfc5','login=%26id%3D3105714%26pw%3D48261db8c4be6160c47b23acb34ff39ff249028b%26cks%3Dec8902c142b5',),
							),

	'uploaded.net'		=> array(
								'max_size'	=> 8192,
								'accounts'	=> array(),
							),

	'mega.co.nz'		=> array(
								'max_size'	=> 15360,
								'accounts'	=> array('moi:passe',),
							),

	'bitshare.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'gigasize.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'uploadable.ch'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array('byMrBLAKEN/:154651rtret5r51ez1561ztzzrt1zt163',),
							),

	'uploadstation.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'enterupload.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'4shared.com'		=> array(
								'max_size'	=> 15360,
								'accounts'	=> array('byMrBLAKEN/:z1000khoya',),
							),

	'filesmonster.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'fileparadox.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'letitbit.net'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'crocko.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'freakshare.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'extabit.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'turbobit.net'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array('byMrBLAKEN/:154651rtret5r51ez1561ztzzrt1zt163',),
							),

	'share-online.biz'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array('byMrBLAKEN/:troudeballe007',),
							),

	'sendspace.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array('12354:123654',),
							),

	'solidfiles.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array('byMrBLAKEN/:154651rtret5r51ez1561ztzzrt1zt163',),
							),

	'rapidgator.net'		=> array(
								'max_size'	=> 15360,
								'accounts'	=> array('eye8urface@msn.com:Steven123',),
							),

	'rapidgator2.net'		=> array(
								'max_size'	=> 15360,
								'accounts'	=> array('Darrenc858@Hotmail.com:qwe2qwe2',),
							),

	'novafile.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array('7520378:suncr0ft','gonfalone:homeboy',),
							),

	'metacafe.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array('byMrBLAKEN/:154651rtret5r51ez1561ztzzrt1zt163',),
							),

	'uppit.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array('byMrBLAKEN/:154651rtret5r51ez1561ztzzrt1zt163',),
							),

	'rodfile.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array('byMrBLAKEN/:154651rtret5r51ez1561ztzzrt1zt163',),
							),

	'novamov.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array('byMrBLAKEN/:154651rtret5r51ez1561ztzzrt1zt163',),
							),

	'dailymotion.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array('byMrBLAKEN/:154651rtret5r51ez1561ztzzrt1zt163',),
							),

	'oboom.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array('byMrBLAKEN/:154651rtret5r51ez1561ztzzrt1zt163',),
							),

	'purevid.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array('byMrBLAKEN/:154651rtret5r51ez1561ztzzrt1zt163',),
							),

	'uplea.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array('byMrBLAKEN/:154651rtret5r51ez1561ztzzrt1zt163',),
							),

	'filepost.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array('byMrBLAKEN/:troudeballe007',),
							),

	'youtube.com'		=> array(
								'max_size'	=> 8048,
								'accounts'	=> array('byMrBLAKEN/:154651rtret5r51ez1561ztzzrt1zt163',),
							),

	'youwatch.org'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array('byMrBLAKEN/:154651rtret5r51ez1561ztzzrt1zt163',),
							),

	'youporn.com'		=> array(
								'max_size'	=> 4096,
								'accounts'	=> array('byMrBLAKEN/:154651rtret5r51ez1561ztzzrt1zt163',),
							),

	'dfiles.eu'		=> array(
								'max_size'	=> 4096,
								'accounts'	=> array('byMrBLAKEN/:154651rtret5r51ez1561ztzzrt1zt163',),
							),

	'alldebrid.com'		=> array(
								'max_size'	=> 102400,
								'accounts'	=> array(),
							),

);
$this->max_size_other_host = 102400;

?>