<?php

$this->acc = array(
# Example: 'accounts'	=> array('user:pass','cookie'),
# Example with letitbit.net: 'accounts'    => array('user:pass','cookie','prekey=xxxx'),


	'debriditalia.com'		=> array(
								'max_size'	=> 500,
								'accounts'	=> array('dada442301:dada442301',),
							),

	'uptobox.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array("123123:12313",),
							),

);
$this->max_size_other_host = 102400;

?>