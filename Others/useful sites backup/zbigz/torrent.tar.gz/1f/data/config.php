<?php
$Secure = true; 
$password= array("k4ZAs3xN3Q@3hhWm86@33a8A7r28dbMwL");

$homepage = "";
$fileinfo_dir = 'data';
$fileinfo_ext = "dat";
$filecookie ="cookie.php";

$download_prefix = "";
$limitMBIP = 11440000;
$ttl = 60*12;
$limitPERIP = 100;
$ttl_ip = 1;
$max_jobs_per_ip = 100000;
$max_jobs = 1000000;
$max_load = 75;

$title = "[color=red]..::] DOWNLOAD [::..[/color]";
$colorfilename = "black";
$colorfilesize = "darkblue";

$ziplink = false;

$apif = "https://linkshrink.net/api.php?key=e0f&url=";

$directttlink = true;

$listfile = true;
$privatefile = false;
$privateip = false;
$checkacc = true;
$checklinksex = true;

$action = array(
'rename' => true,
'delete' => false,
);

$debrid = true;
//$plugin = 'alldebrid_com.php';
//$plugin = 'conexaomega_com.php';
//$plugin = 'conexaomega_com_br.php';
//$plugin = 'contasturbo_com.php';
//$plugin = 'debriditalia_com.php';
//$plugin = 'debridmax_com.php';
//$plugin = 'downmasters_com.php';
//$plugin = 'fast-debrid_com.php';
//$plugin = 'ffdownloader_com.php';
//$plugin = 'linksnappy_com.php';
//$plugin = 'megarapido_net.php';
//$plugin = 'multi-debrid_com.php';
//$plugin = 'premiumize_me.php';
//$plugin = 'real-debrid_com.php';
//$plugin = 'rehost_to.php';
//$plugin = 'rpnet_biz.php';
//$plugin = 'simply-debrid_com.php';
//$plugin = 'superdown_com_br.php';
//$plugin = 'superlinksbr_com.php';
//$plugin = 'zevera_com.php';


$badword = array("porn","jav ", "Uncensored","xxx japan", "tora.tora", "tora-tora", "SkyAngle", "Sky_Angel", "Sky.Angel", "Incest","fuck", "Virgin", "PLAYBOY", "Adult", "tokyo hot", "Gangbang", "BDSM", "Hentai", "lauxanh", "homosexual", "bitch" , "Torture", "Nurse", "d?m d?ng", "c?c d?m", "phim c?p 3", "phim 18+", " Hentai", "Sex Videos", "Adult", "Adult XXX", "XXX movies", "Free Sex", "hardcore", "rape", "jav4u", "javbox", "jav4you", "akiba-online.com","JAVbest.ORG","X-JAV","cnnwe.com","J4v.Us","J4v.Us","teendaythi.com","entnt.com","khikhicuoi","sex-scandal.us","hotavxxx.com"); 


require_once ('languages.php');
?>