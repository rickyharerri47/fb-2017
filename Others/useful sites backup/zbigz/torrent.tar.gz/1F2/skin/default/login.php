<html>
	<head>
		<meta http-equiv="Content-Language" content="en-us">
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link rel="SHORTCUT ICON" href="images/vngicon.png" type="image/x-icon" />
		<meta name="keywords" content="<?php printf($obj->lang['version']); ?>, download, get, vinaget, file, generator, premium, link, sharing, bitshare.com, crocko.com, depositfiles.com, extabit.com, filefactory.com, filepost.com, filesmonster.com, freakshare.com, gigasize.com, hotfile.com, jumbofiles.com, letitbit.net, mediafire.com, megashares.com, netload.in, oron.com, rapidgator.net, rapidshare.com, ryushare.com, sendspace.com, share-online.biz, shareflare.net, uploaded.to, uploading.com" />
		<title><?php printf($obj->lang['title'],$obj->lang['version']); ?></title>
		<style>
		body {
			background: #000000 repeat-x;
			font: 75%/170% Arial, Helvetica, sans-serif;
			padding: 0px;
			margin: 0px;
			color: #333333;
		}
		a { color: #55aaff; }
		.login {
			color: #FFFFFF;
			font-weight:bold;
			font-family: Arial;
		}
		.pass {
			color: #CCCCCC;
			font-weight:bold;
			font-family: Bookman Old Style;
		}
		.powered {
			font-family: Arial;
			color: #FF8700;
			font-size: 10px;
			line-height: 14px;
			font-weight:bold;
		}
		.copyright {
			font-family: Arial;
			line-height: 14px;
			color: #CCCCCC;
			font-size: 10px;
			font-weight:bold;
		}
		.copyright a {
			color: red;
			TEXT-DECORATION: none;
		}
		</style>
	</head>
	<body>
		<p align="center"><br/>
		<code><span style="color: #FF3300; FONT-SIZE: 14px"><B>
			::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::<BR>
			::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::<BR>
			::HHHHHH::::::HHHHHH::HHHHHH::::HHHH::::::::::HHHH::::::HHHHHHHHHH::::::::::::HHHHHHHHHHHH::::::HHHHHHHHHHHHHH::HHHHHHHHHHHHHHHHHH::<BR>
			::HHHHHH::::::HHHHHH::HHHHHH::::HHHHHH::::::::HHHH::::::HHHHHHHHHH::::::::::HHHHHHHHHHHHHHHH::::HHHHHHHHHHHHHH::HHHHHHHHHHHHHHHHHH::<BR>
			::::HHHHHH::HHHHHH::::HHHHHH::::HHHHHHHH::::::HHHH::::HHHHHHHHHHHHHH::::::HHHHHHHH::::HHHHHH::::HHHHHH::::::::::::::::HHHHHH::::::::<BR>
			::::HHHHHH::HHHHHH::::HHHHHH::::HHHHHHHHHH::::HHHH::::HHHHHH::HHHHHH::::::HHHHHH::::::::::::::::HHHHHH::::::::::::::::HHHHHH::::::::<BR>
			::::HHHHHH::HHHHHH::::HHHHHH::::HHHH::HHHHHH::HHHH::::HHHHHH::HHHHHH::::::HHHHHH::::HHHHHHHH::::HHHHHHHHHHHHHH::::::::HHHHHH::::::::<BR>
			::::::HHHH::HHHH::::::HHHHHH::::HHHH::HHHHHH::HHHH::::HHHHHH::HHHHHH::::::HHHHHH::::HHHHHHHH::::HHHHHHHHHHHHHH::::::::HHHHHH::::::::<BR>
			::::::HHHH::HHHH::::::HHHHHH::::HHHH::::HHHHHHHHHH::::HHHHHHHHHHHHHH::::::HHHHHH::::::HHHHHH::::HHHHHH::::::::::::::::HHHHHH::::::::<BR>
			::::::HHHHHHHHHH::::::HHHHHH::::HHHH::::::HHHHHHHH::HHHHHHHHHHHHHHHHHH::::HHHHHHHH::::HHHHHH::::HHHHHH::::::::::::::::HHHHHH::::::::<BR>
			::::::::HHHHHH::::::::HHHHHH::::HHHH::::::::HHHHHH::HHHHHH::::::HHHHHH::::::HHHHHHHHHHHHHHHH::::HHHHHHHHHHHHHH::::::::HHHHHH::::::::<BR>
			::::::::HHHHHH::::::::HHHHHH::::HHHH::::::::::HHHH::HHHHHH::::::HHHHHH::::::::HHHHHHHHHH::::::::HHHHHHHHHHHHHH::::::::HHHHHH::::::::<BR>
			::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::<BR>
			::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::<BR>
			</B><BR></span>
		</code>
		<div align="center">
			<form method="POST" action="login.php">
				<span class='login'><?php printf($obj->lang['login']); ?></span>
				<table border="0" width="500" height="32">
					<tr>
						<td height="28" width="108"><span class='pass'><?php printf($obj->lang['password']); ?></span></td>
						<td height="28" width="316"><input type="password" name="secure" size="44"></td>
						<td height="28" width="56"><input type="submit" value="Submit" name="submit"></td>
					</tr>
				</table>
			</form>
			<br/>
		<!-- Copyright please don't remove-->
			<STRONG><SPAN class='powered'>Code LeechViet. Developed by ..:: [H] ::..<br/>Powered by <a href='http://www.rapidleech.com/index.php/topic/14663-dev-vinaget-v270-beta/'><?php printf($obj->lang['version']); ?> Revision <?php printf($obj->current_version); ?></a> by [FZ]</SPAN><br/>
			<SPAN class='copyright'>Copyright 2009-<?php echo date('Y');?> by <a href='http://vinaget.us/'>http://vinaget.us</a>. All rights reserved. </SPAN><br />
		<!-- Copyright please don't remove-->	
		</div>
	</body>
	</html>